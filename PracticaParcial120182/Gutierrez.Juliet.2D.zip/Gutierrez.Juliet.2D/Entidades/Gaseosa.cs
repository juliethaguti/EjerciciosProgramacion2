﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Gaseosa : Producto
    {
        protected float _litros;
        protected static bool DeConsumo;

        #region Propiedad
        public override float CalcularCostoDeProduccion
        {
            get
            {
                return (this.Precio * (float)0.42);
            }
        }
        #endregion

        #region Constructores
        static Gaseosa()
        {
            DeConsumo = true;
        }

        public Gaseosa(int codigoDeBarra, float precio, EMarcaProducto marca,float litros)
            : base(codigoDeBarra,marca,precio)
        {
            this._litros = litros;
        }

        public Gaseosa(Producto p, float litros)
            : this((int)p,p.Precio,p.Marca,litros)
        {

        }
        #endregion

        #region Métodos
        public override string Consumir()
        {
            return "Bebible";
        }

        string MostrarGaseosa()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("COSTO:\t{0}", this.CalcularCostoDeProduccion);
            sb.AppendFormat("LITROS:\t{0}", this._litros);

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.MostrarGaseosa();
        }
        #endregion
    }
}
