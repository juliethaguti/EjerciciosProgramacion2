﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{ 
    public abstract class Producto
    {
        #region Enumerados
        public enum EMarcaProducto
        {
            Manaos, Pitusas, Naranjú, Diversión, Swift, Favorita
        }

        public enum ETipoProducto
        {
            Galletita, Gaseosa, Jugo, Harina, Todos
        }
        #endregion

        #region Atributos
        protected int _codigoBarra;
        protected EMarcaProducto _marca;
        protected float _precio;
        #endregion

        #region Propiedades
        public virtual float CalcularCostoDeProduccion { get; }

        public EMarcaProducto Marca
        {
            get
            {
                return this._marca;
            }
        }

        public float Precio
        {
            get
            {
                return this._precio;
            }
        }
        #endregion

        #region Constructor
        public Producto(int codigoBarra, EMarcaProducto marca, float precio)
        {
            this._codigoBarra = codigoBarra;
            this._marca = marca;
            this._precio = precio;
        }
        #endregion

        #region Métodos
        public virtual string Consumir()
        {
            return "Parte de una mezcla"; 
        }

        protected string MostrarProducto(Producto p)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("MARCA:\t{0}\n", this.Marca);
            sb.AppendFormat("CODIGO DE BARRA:\t{0}\n", this._codigoBarra);
            sb.AppendFormat("PRECIO: {0}\n", this.Precio);

            return sb.ToString();
        }
        #endregion

        #region Sobrecargas
        public override bool Equals(object obj)
        {
            return (obj.GetType() == this.GetType());
        }

        public static explicit operator int(Producto p)
        {
            return p._codigoBarra;
        }

        public static implicit operator string(Producto p)
        {
            return p.MostrarProducto(p);
        }

        public static bool operator ==(Producto proUno, EMarcaProducto marca)
        {
            bool retorno = false;

            if(proUno.Marca == marca)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator ==(Producto proUno, Producto proDos)
        {
            bool retorno = false;

            if(proUno.GetType() == proDos.GetType())
            {
                if(proUno.Marca == proDos.Marca && 
                    proDos._codigoBarra == proUno._codigoBarra)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Producto proUno, EMarcaProducto marca)
        {
            return !(proUno == marca);
        }

        public static bool operator !=(Producto proUno, Producto proDos)
        {
            return !(proUno == proDos);
        }
        #endregion
    }
}
