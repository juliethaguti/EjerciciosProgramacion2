﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Galletita : Producto
    {
        protected float _peso;
        static bool DeConsumo;

        #region Propiedades
        public override float CalcularCostoDeProduccion
        {
            get
            {
                return (this.Precio * (float)0.33);
            }
        }
        #endregion

        #region Constructores
        static Galletita()
        {
            DeConsumo = true;
        }
        public Galletita(int codigoDeBarra,float precio,EMarcaProducto marca, float peso)
            : base(codigoDeBarra,marca,precio)
        {
            this._peso = peso;
        }
        #endregion

        #region Métodos
        public override string Consumir()
        {
            return "Comestible";
        }

        private string MostrarGalletita(Galletita g)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("COSTO:\t{0}", this.CalcularCostoDeProduccion);
            sb.AppendFormat("PESO:\t{0}", this._peso);

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.MostrarGalletita(this);
        }
        #endregion
    }
}
