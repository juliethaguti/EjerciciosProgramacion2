﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estante
    {
        protected sbyte _capacidad;
        protected List<Producto> _productos;

        #region Propiedad
        public float ValorEstanteTotal
        {
            get
            {
                return this.GetValorEstante();
            }
        }
        #endregion

        #region Constructores
        private Estante()
        {
            this._productos = new List<Producto>();
        }

        public Estante(sbyte capacidad) 
            : this()
        {
            this._capacidad = capacidad;
        }
        #endregion

        #region
        public List<Producto> GetProductos()
        {
            return this._productos;
        }

        public float GetValorEstante()
        {
            float valorEstante = 0;
            foreach (Producto p in this.GetProductos())
            {
                valorEstante += p.Precio; 
            }
            return valorEstante;
        }

        public float GetValorEstante(Producto.ETipoProducto tipo)
        {
            float precioTotal = 0;
            switch(tipo)
            {
                case Producto.ETipoProducto.Galletita:
                    foreach(Producto p in this.GetProductos())
                    {
                        if(p is Galletita)
                        {
                            precioTotal += p.Precio;
                        }
                    }
                    break;
                case Producto.ETipoProducto.Gaseosa:
                    foreach (Producto p in this.GetProductos())
                    {
                        if (p is Gaseosa)
                        {
                            precioTotal += p.Precio;
                        }
                    }
                    break;
                case Producto.ETipoProducto.Harina:
                    foreach (Producto p in this.GetProductos())
                    {
                        if (p is Harina)
                        {
                            precioTotal += p.Precio;
                        }
                    }
                    break;
                case Producto.ETipoProducto.Jugo:
                    foreach (Producto p in this.GetProductos())
                    {
                        if (p is Jugo)
                        {
                            precioTotal += p.Precio;
                        }
                    }
                    break;
                default:
                    foreach (Producto p in this.GetProductos())
                    {
                        precioTotal += p.Precio;
                    }
                    break;
            }
            return precioTotal;
        }

        public static string MostrarEstante(Estante e)
        {
            StringBuilder sb = new StringBuilder();

            foreach(Producto p in e.GetProductos())
            {
                sb.AppendLine(p);
            }

            return sb.ToString();
        }
        #endregion

        #region Sobrecargas
        public static bool operator !=(Estante e, Producto prod)
        {
            return !(e == prod);
        }

        public static bool operator ==(Estante e, Producto prod)
        {
            bool retorno = false;

            foreach(Producto p in e.GetProductos())
            {
                if(prod == p)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static Estante operator -(Estante e, Producto.ETipoProducto tipo)
        {
            switch(tipo)
            {
                case Producto.ETipoProducto.Galletita:
                    foreach(Producto p in e.GetProductos())
                    {
                        if(p is Galletita)
                        {
                            e._productos.Remove(p);
                        }
                    }
                    break;
                case Producto.ETipoProducto.Gaseosa:
                    foreach (Producto p in e.GetProductos())
                    {
                        if (p is Gaseosa)
                        {
                            e._productos.Remove(p);
                        }
                    }
                    break;
                case Producto.ETipoProducto.Harina:
                    foreach (Producto p in e.GetProductos())
                    {
                        if (p is Harina)
                        {
                            e._productos.Remove(p);
                        }
                    }
                    break;
                case Producto.ETipoProducto.Jugo:
                    foreach (Producto p in e.GetProductos())
                    {
                        if (p is Jugo)
                        {
                            e._productos.Remove(p);
                        }
                    }
                    break;
            }
            return e;
        }

        public static Estante operator -(Estante e, Producto prod)
        {
            if(e == prod)
            {
                e._productos.Remove(prod);
            }

            return e;
        }

        public static bool operator +(Estante e, Producto prod)
        {
            bool retorno = false;
            if(e.GetProductos().Count < e._capacidad && !(e == prod))
            {
                e.GetProductos().Add(prod);
                retorno = true;
            }
            return retorno;
        }
        #endregion
    }
}
