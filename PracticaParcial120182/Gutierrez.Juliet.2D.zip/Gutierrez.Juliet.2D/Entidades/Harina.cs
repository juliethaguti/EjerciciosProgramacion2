﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Harina : Producto
    {
        private ETipoHarina _tipo;
        protected static bool DeConsumo;

        #region Enumerado
        public enum ETipoHarina
        {
            CuatroCeros, TresCeros, Integral
        }
        #endregion

        #region Propiedades
        public override float CalcularCostoDeProduccion
        {
            get
            {
                return (this.Precio * (float)0.6);
            }
        }
        #endregion

        #region Constructores
        static Harina()
        {
            DeConsumo = false;
        }

        public Harina(int codigo, float precio, EMarcaProducto marca, ETipoHarina tipo)
            : base(codigo,marca,precio)
        {
            this._tipo = tipo;
        }
        #endregion

        #region Métodos
        string MostrarHarina()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("COSTO: {0}", this.CalcularCostoDeProduccion);
            sb.AppendFormat("TIPO: {0}", this._tipo);

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.MostrarHarina();
        }
        #endregion
    }
}
