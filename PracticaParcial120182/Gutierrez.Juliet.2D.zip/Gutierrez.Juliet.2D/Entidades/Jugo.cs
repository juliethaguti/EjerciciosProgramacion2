﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugo : Producto
    {
        #region Enumerado
        public enum ESaborJugo
        {
            Asqueroso, Pasable, Rico
        }
        #endregion

        protected ESaborJugo _sabor;
        private static bool deConsumo;

        #region Propiedad
        public override float CalcularCostoDeProduccion
        {
            get
            {
                float costo = this.Precio * (float)0.4;
                return costo;
            }
        }
        #endregion
        #region Constructor
        static Jugo()
        {
            deConsumo = true;
        }

        public Jugo(int codigoBarra,float precio, EMarcaProducto marca,ESaborJugo sabor)
            : base(codigoBarra,marca,precio)
        {
            this._sabor = sabor;
        }
        #endregion

        #region Métodos
        public override string Consumir()
        {
            return "Bebible";
        }

        private string MostrarJugo()
        {
            StringBuilder sb = new StringBuilder();

            //sb.AppendFormat("JUGO");
            //sb.AppendFormat("MARCA: {0}", this.Marca);
            //sb.AppendFormat("CODIGO DE BARRAS: {0}", (Producto)this);
            //sb.AppendFormat("PRECIO: {0}", this.Precio);
            sb.AppendFormat("COSTO:\t{0}",this.CalcularCostoDeProduccion);
            sb.AppendFormat("SABOR:\t{0}",this._sabor);

            return sb.ToString();
        }
        #endregion

        #region Sobrecargas
        public override string ToString()
        {
            return this.MostrarJugo();
        }
        #endregion
    }
}
