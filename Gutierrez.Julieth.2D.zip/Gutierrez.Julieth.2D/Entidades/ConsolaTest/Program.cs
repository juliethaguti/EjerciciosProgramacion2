﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using EntidadesInstanciables;

namespace ConsolaTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Negocio n = new Negocio("El negocio");

            Fruta manzana = new Fruta("manzana", 1);
            Fruta fresa = new Fruta("fresa", 2);

            Verdura Tomate = new Verdura("tomate", 3);
            Verdura cebolla = new Verdura("cebolla", 4);

            n += manzana;
            n += fresa;
            n += Tomate;
            n += cebolla;

            n.ToString();
        }
    }
}
