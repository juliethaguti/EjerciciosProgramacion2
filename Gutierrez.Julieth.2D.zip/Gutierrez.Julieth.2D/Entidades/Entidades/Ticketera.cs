﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesEstaticas
{
    public class Ticketera
    {
        private static int numero;

        static Ticketera()
        {
            numero = 1;
        }

        #region Propiedades
        public int ResetNumero 
        {
            set
            {
                numero = value ;
            }
        }
        #endregion

        #region Metodos
        public static int EntregarTicket()
        {
            numero++;
            return numero;
        }
        #endregion
    }
}
