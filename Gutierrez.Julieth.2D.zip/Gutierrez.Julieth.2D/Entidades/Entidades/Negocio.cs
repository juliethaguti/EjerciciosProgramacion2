﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesEstaticas;
using Entidades;

namespace EntidadesInstanciables
{
    public class Negocio
    {
        private Queue<int> fila;
        private string nombre;
        private int[] turno = new int [10];
        private List<Producto> elementos = new List<Producto>();

        #region Propiedades
        public int Turno {
            get
            {
                return this.fila.Dequeue();
            }
        }
        #endregion
        #region Constructores
        private Negocio()
        {
            fila = new Queue<int>();
        }

        public Negocio(string nombre)
        {
            this.nombre = nombre;
        }
        #endregion

        public static Negocio operator +(Negocio n, Ticketera t)
        {
            //n.fila.Enqueue();
            return n;
        }

        public static Negocio operator +(Negocio n, int numero)
        {
            n.fila.Enqueue(numero);
            return n;
        }

        public static Negocio operator +(Negocio n, Producto p)
        {
            n.elementos.Add(p);
            return n;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("NOMBRE DEL NEGOCIO: " + this.nombre);
            sb.AppendLine("PRODUCTOS");
            foreach( Producto producto in elementos)
            {
                sb.AppendLine(producto.Mostrar());
            }

 	        return sb.ToString();
        }



    }
}
