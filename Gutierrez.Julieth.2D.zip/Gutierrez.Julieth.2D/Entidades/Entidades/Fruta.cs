﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fruta : Producto
    {
        private string nombre;
        private float precio;

        #region Propiedades
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public float Precio
        {
            get
            {
                return this.precio;
            }
            set
            {
                this.precio = value;
            }
        }
        #endregion

        #region Constructor
        public Fruta(string nombre, float precio)
            : base(nombre, precio)
        {

        }
        #endregion

        public override string Mostrar()
        {
            return base.Mostrar();
        }
    }
}
