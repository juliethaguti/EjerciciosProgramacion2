﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesInstanciables;
using Entidades;

namespace FormTest
{
    public partial class Form1 : Form
    {
        private Negocio miNegocio;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Negocio n = new Negocio("El negocio");
            Fruta manzana = new Fruta("manzana", 1);
            Fruta fresa = new Fruta("fresa", 2);

            Verdura Tomate = new Verdura("tomate", 3);
            Verdura cebolla = new Verdura("cebolla", 4);

            n += manzana;
            n += fresa;
            n += Tomate;
            n += cebolla;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Seguro quiere salir?", "Advertencia", MessageBoxButtons.YesNo);
           
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            rtbSalida.Clear();
            
        }
    }
}
